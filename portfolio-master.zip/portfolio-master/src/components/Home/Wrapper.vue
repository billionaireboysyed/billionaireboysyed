<template>
    <section class="scene" id="wrapperTitle">
        <div class="static-container">
            <h1 class="title">
                &lt;/wrapper&gt;
            </h1>
            <div class="std">
                <p class="-gray">
                    /*<br>
                    - Close your eyes. What do you hear?<br>
                    <span class="-answer">- I hear the water, I hear the birds.</span><br>
                    - Do you hear your own heartbeat?<br>
                    <span class="-answer">- No.</span><br>
                    - Do you hear the grasshopper which is at your feet?<br>
                    <span class="-answer">- Old man, how is it that you hear these things?</span><br>
                    - Young man, how is it that you do not?<br>
                    */
                </p>
            </div>
        </div>
    </section>
</template>

<script>
    export default {
        name: 'Wrapper'
    }
</script>