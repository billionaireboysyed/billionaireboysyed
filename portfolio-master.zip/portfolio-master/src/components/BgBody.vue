<template>
    <div class="body-bg">
        <div class="-default"></div>
        <div class="-mario"></div>
        <div class="-admin"></div>
        <div class="-confianca"></div>
        <div class="-desbravando"></div>
    </div>
</template>

<script>
    export default {
        name: 'BgBody'
    }
</script>