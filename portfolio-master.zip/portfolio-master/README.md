# iuri.is()

This is my portfolio.<br>
It was built using Vue CLI, GSAP, NProgress and ScrollMagic.

Almost all configuration files have been left with the default settings.

Feel free to copy and reuse any resources in this repository.

### Live website

[iuri.is](https://iuri.is/)